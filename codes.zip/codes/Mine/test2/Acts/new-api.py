#Health Check
@app.route('/api/v1/_health',methods=['GET'])
def check_server_health():
        #print("Entry point")
        global crash
        resp=requests.get('http://172.31.80.169:8000/api/v1/categories')
        #print("what happened")
        #print(resp.status_code)
        print(resp.json)
        if crash == 1:
                return make_response(jsonify({}),500)
        elif resp.status_code==200:
            #print("server is working properly")
            return make_response(jsonify({}),200)
        else:
            #print("Server isn't working")
            return make_response(jsonify({}),500)

#Crash Server code 
@app.route('/api/v1/_crash',methods=['POST'])
def crash_server():
        global crash
        if crash==0:
                crash =1
                return make_response(jsonify({}),200)



