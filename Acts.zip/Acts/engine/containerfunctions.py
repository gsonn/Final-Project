import docker
import subprocess
import os,sys

client = docker.from_env()


def launch_container1(port):
    container = client.containers.run("acts", ports={'80':str(port)},detach=True)
    return container.id
'''

def launch_container(port):
    list=["docker","run","-p",port:80,"acts"]
    ss=subprocess.run(list,std)




def list_container1():
    list2=["docker","ps","-a","-q"]
    ss=subprocess.run(list2,stdout=subprocess.PIPE)
    id=ss.stdout.decode()
    #f=open('file.txt','w')
    #print(id)
    #f.write(id)
    #print(id)
    #return ss
    stop_single_container()
    #print(type(ss))
    return id


#To stop all containers
def stop_all_containers():
    for container in client.containers.list():
        container.stop()

def stop_single_container():
    subprocess.call('docker stop $(docker ps -a -q)[0]',shell=True)

#
#a=list_container()
f=open('file.csv','w')
#sys.stdout=f
#print()
#stop_all_containers()
#stop_single_container(a)


#print(type(a))


#stop_single_container(a)

#To stop any perticular container



#To print logs of specific container
def print_logs_specific(containerId):
    container=client.containers.get(containerId)
    print=container.logs()


'''
