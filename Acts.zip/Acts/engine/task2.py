from flask import Flask, jsonify, abort
import math
import csv
from flask import make_response
import datetime
from flask import request
import sys
import subprocess
import time
import containerfunctions as cf
import test as test
import requests
app=Flask(__name__)


count = 0
crash = 0
l=[8000]


#Routing the request to different containers
@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error':'not found'}),404)



#Health Check
@app.route('/api/v1/_health',methods=['GET'])
def check_server_health(port):
        #print("Entry point")
        global crash
        resp=requests.get('http://127.0.0.1:80/api/v1/categories')
        #print("what happened")
        #print(resp.status_code)
        print(resp.json)
        if crash == 1:
                return make_response(jsonify({}),500)
        elif resp.status_code==200:
            #print("server is working properly")
            return make_response(jsonify({}),200)
        else:
            #print("Server isn't working")
            return make_response(jsonify({}),500)



#Crash Server code
@app.route('/api/v1/_crash',methods=['POST'])
def crash_server():
        global crash
        if crash==0:
                crash = 1
                return make_response(jsonify({}),200)



# return total number of request
@app.route('/api/v1/_count',methods=['GET'])
def total_request():
    list=[]
    list.append(count)
    return make_response(jsonify(list),200)


# reset the request count to zero
@app.route('/api/v1/_count',methods=['DELETE'])
def set_request_zero():
    list=[]
    global count
    count = 0
    list.append(count)
    #return make_response(jsonify(list),200)
    return make_response(jsonify({}),200)


# get total number of acts
@app.route('/api/v1/acts/count',methods=['GET'])
def total_countsof_acts():
    global count
    count = count + 1
    list=[]
    t_acts = 0
    with open('acts.csv') as csv_file:
        csv_reader=csv.reader(csv_file)
        for row in csv_reader:
            t_acts = t_acts + 1
        list.append(t_acts)
    return make_response(jsonify(list),200)


@app.route('/api/v1/categories',methods=['GET'])
def category_requests():
    print("Entry Point")
    global count
    i = (count+1)%(len(l))
    count = count + 1
    resp=requests.get('http://127.0.0.1:80/api/v1/_health')
    print("Health request Done")
    d=resp.json()
    if resp.status_code == 200:
        resp1=requests.get('http://127.0.0.1:80/api/v1/categories')
        print("Category request Done")
        result=resp.json()
        return jsonify(result),resp1.status_code





@app.route('/api/v1/categories',methods=['POST'])
def some6():
    return 1

@app.route('/api/v1/categories/<categoryName>',methods=['DELETE'])
def some7():
    return 1

@app.route('/api/v1/acts',methods=['POST'])
def some8():
    return 1

@app.route('/api/v1/acts/<actId>',methods=['DELETE'])
def some9():
    return 1

@app.route('/api/v1/acts/upvote',methods=['POST'])
def some10():
    return 1

@app.route('/api/v1/categories/<categoryname>/acts', methods=['GET'])
def some11():
    return 1

@app.route('/api/v1/categories/<categoryname>/acts/size', methods=['GET'])
def some12():
    return 1

@app.route('/api/v1/categories/<categoryname>/acts', methods=['GET'])
def some13():
    return 1



if __name__ == '__main__':
    app.run(host='127.0.0.1',port=5000)
