#-*- coding: utf-8 -*-
from flask import Flask, jsonify,render_template,flash,url_for,redirect,request,Response
from werkzeug import secure_filename
import os
import json
import time
import shutil
import base64
import binascii
import re
import hashlib
from flask_cors import CORS
import requests
import containerfunctions as cf

app= Flask(__name__)
print(app)
count =0
l=[8000,8001,8002]

def check_time(timestamp):
	pattern = re.compile("[0-3]{1}[0-9]{1}-[0-1]{1}[0-9]{1}-[0-9]{4}:[0-5]{1}[0-9]{1}-[0-5]{1}[0-9]{1}-[0-2]{1}[0-9]{1}")
	if not timestamp or (len(timestamp) < 1):
		return False
	else:
		return pattern.match(timestamp)

def isBase64(s):
	'''if re.match("^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)?$",s):
		return True
	else:
		return False'''
	return True


'''
def get_user(user_name):
	url="http://54.196.230.51:3000/api/v1/users"
	r=requests.get(url)
	data=r.json()

	if user_name in data:
		return True
	else:
		return False

'''




@app.route("/api/v1/acts/upvote",methods=['POST'])
def upvote():
	global count
	i = (count +1)%(len(l))
	count = count + 1
	if request.method=='POST':
		d=request.data
        print(d)
		r=requests.post('http://54.196.230.51:'+str(l[i])+'/api/v1/acts/upvote',data=d)
		return jsonify({}),r.status_code




@app.route("/api/v1/acts/test",methods=['POST'])
def test():
	a=request.get_json(force=True)
	print(a)
	return str({}),200








@app.route("/api/v1/categories/<categoryName>/acts?start=<start>&end=<end>",methods=['GET'])
def incl_list(categoryName,start,end):
	global count
	i = (count +1)%(len(l))
	count = count + 1
	r=requests.get('http://54.196.230.51:'+str(l[i])+'/api/v1/categories/<categoryName>/acts?start=<start>&end=<end>')
	d = r.json()
	return jsonify(d),r.status_code

@app.route("/api/v1/categories",methods = ['GET','POST'])
def add_and_list():
	global count

	if request.method=='GET':
		i = (count +1)%(len(l))
		count = count + 1
		r=requests.get('http://54.196.230.51:'+str(l[i])+'/api/v1/categories')
		d = r.json()
		return jsonify(d),r.status_code


	elif request.method=='POST':
		i = (count +1)%(len(l))
		count = count + 1
		d=request.data
		r=requests.post('http://54.196.230.51:'+str(l[i])+'/api/v1/categories',data=d)
		return jsonify({}),r.status_code
	else:
		return Response("{}",status=400,mimetype='application/json')





@app.route("/api/v1/categories/<categoryName>/acts",methods = ['GET'])
def list_category(categoryName):
	global count
	i = (count +1)%(len(l))
	count = count + 1
	r=requests.get('http://54.196.230.51:'+str(l[i])+'/api/v1/categories/'+categoryName+'/acts')
	d = r.json()
	return jsonify(d),r.status_code








@app.route("/api/v1/categories/<categoryName>/acts/size",methods = ['GET'])
def no_of_acts(categoryName):
	global count
	i = (count +1)%(len(l))
	count = count + 1
	r=requests.get('http://54.196.230.51:'+str(l[i])+'/api/v1/categories/'+categoryName+'/acts/size')
	d = r.json()
	return jsonify(d),r.status_code




@app.route("/api/v1/categories/<category>",methods=['DELETE'])
def cata_remove(category):
	global count
	i = (count +1)%(len(l))
	count = count + 1
	r=requests.delete('http://54.196.230.51:'+str(l[i])+'/api/v1/categories/'+category)
	d = r.json()
	return jsonify(d),r.status_code




@app.route("/api/v1/acts/<actId>",methods=['DELETE'])
def act_remove(actid):
	global count
	i = (count +1)%(len(l))
	count = count + 1
	r=requests.delete('http://54.196.230.51:'+str(l[i])+'/api/v1/acts/'+str(actId))
	d = r.json()
	return jsonify(d),r.status_code


@app.route('/api/v1/acts',methods=['POST'])
def upload_act():
	global count
	i = (count +1)%(len(l))
	count = count + 1
	d=request.data
	r=requests.post('http://54.196.230.51:'+str(l[i])+'/api/v1/acts',data=d)
	return jsonify({}),r.status_code

#
# @app.route("/api/v1/acts/count",methods = ['GET'])
# def total_acts_count():
# 	global count
# 	count = count + 1
# 	if request.method != 'GET':
# 		return jsonify({}),405
# 	else:
# 		try :
# 			f=open('acts.txt','r')
# 			f.close()
# 		except FileNotFoundError:
# 			f=open ('acts.txt','w')
# 			d={}
# 			json.dump(d,f)  # add these two lines wherver
# 			f.close()
# 		f=open('acts.txt','r')
# 		act=json.load(f)
# 		c = len(act)
# 		l=[]
# 		l.append(c)
# 		return jsonify(l),200

@app.route("/api/v1/_count",methods = ['GET','DELETE'])
def http_count():
	global count
	if request.method=='GET':
		l=[]
		l.append(count)
		return jsonify(l),200

	elif request.method=='DELETE':

		count =0
		return jsonify({}),200
	else:
			return jsonify({}),405

#checking health of the containers
def health_check(self):
    len=len(l)
    for i in l:
        health=requests.get('http://54.196.230.51:'+str(i)+'/api/v1/_health')
        d=health.json()
        if health.status_code==200:
            return jsonify({}),200
        else:
            a=cf.launch_container1(i)
            return a.id








if __name__ == '__main__':

	app.run("127.0.0.1",80,debug=True)
