#Here main functions are implemented and suroitines are called
from flask import Flask, jsonify, abort
import math
import csv
from flask import make_response
import datetime
from flask import request
import sys
import subprocess
import time
import containerfunctions as cf
app=Flask(__name__)
port =[8000,8001,8002]

for row in port:
    s=launch_container(8000)
    print(s)


if __name__=='__main__':
    app.run(host='127.0.0.1',port=80)



#Have to call health check api's for all the container which are running
