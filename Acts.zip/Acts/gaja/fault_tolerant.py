import docker 
import time
import requests

cli = docker.from_env()


containers={}


ip = "13.233.117.199"
while(1):
	list_cont = cli.containers.list()
	for conta in list_cont:
		port = conta.attrs['NetworkSettings']['Ports']['12345/tcp'][0]['HostPort']
		url = ip+":"+port+"/api/v1/_health"
		res = requests.get(url)
		if(res.status_code==500):
			conta.kill()
			cli.containers.run("acts",ports={'12345/tcp':str(port)},volumes={'database':{'bind':'/app/Database','mode':'rw'}},name="acts"+str(port),remove=True,detach=True)
	time.sleep(1)
