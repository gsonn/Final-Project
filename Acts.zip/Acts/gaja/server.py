from flask import Flask, jsonify,render_template,flash,url_for,redirect,request,redirect
import os
import json
import datetime
import time
import requests
import docker

cli = docker.from_env()

app= Flask(__name__)

ports = [y for y in cli.containers.list() if re.match(r"/acts800[^0]",y.attrs['Name'])]
ptr=-1
count=0

st_url="http://localhost:"

@app.route("/api/v1/categories",methods = ['GET'])
def list_category():
	global ptr
	global count
	ptr+=1
	count+=1
	categories=requests.get(st_url+str(ports[ptr%(len(ports))])+"/api/v1/categories")
	cat = categories.json()
	# return redirect(st_url+str(ports[ptr%(len(ports))])+"/api/v1/categories")
	#return(categories,status)
	return(jsonify(cat),categories.status_code)

# list all categories, add a category , remove a category
# @app.route("/api/v1/categories",methods = ['GET','POST'])
# def categories():
# 	global ptr
# 	global count
# 	ptr+=1
# 	count+=1
# 	if(request.method=='GET'):
# 		return redirect(st_url+str(ports[ptr%(len(ports))])+"/api/v1/categories")
# 	if(request.method=="POST"):
# 		return redirect(st_url+str(ports[ptr%(len(ports))])+"/api/v1/categories",code=308)

@app.route("/api/v1/categories/<categoryName>",methods=['DELETE'])
def remove(categoryName):
	global ptr
	global count
	ptr+=1
	count+=1
	if(request.method=='DELETE'):
		return redirect(st_url+str(ports[ptr%(len(ports))])+"/api/v1/categories/"+categoryName,code=308)

@app.route("/api/v1/categories/<categoryName>/acts",methods=['GET'])
def list_acts(categoryName):
	global ptr
	global count
	ptr+=1
	count+=1
	if(request.method=='GET'):
		return redirect(st_url+str(ports[ptr%(len(ports))])+"/api/v1/categories/"+categoryName+"/acts",code=308)

@app.route("/api/v1/categories/<categoryName>/acts/size",methods=['GET'])
def count_act(categoryName):
	global ptr
	global count
	ptr+=1
	count+=1
	if(request.method=='GET'):
		return redirect(st_url+str(ports[ptr%(len(ports))])+"/api/v1/categories/"+categoryName+"/acts/size",code=308)

@app.route("/api/v1/acts/upvote",methods=['POST'])
def upvote():
	global ptr
	global count
	ptr+=1
	count+=1
	if(request.method=='POST'):
		return redirect(st_url+str(ports[ptr%(len(ports))])+"/api/v1/acts/upvote",code=308)

@app.route("/api/v1/acts/<actId>",methods = ['DELETE'])
def act_delete(actId):
	global ptr
	global count
	ptr+=1
	count+=1
	if(request.method=='DELETE'):
		return redirect(st_url+str(ports[ptr%(len(ports))])+"/api/v1/acts/"+actId,code=308)

@app.route("/api/v1/acts",methods=['POST'])
def upload_act():
	global ptr
	global count
	ptr+=1
	count+=1
	if(request.method=='POST'):
		return redirect(st_url+str(ports[ptr%(len(ports))])+"/api/v1/acts/",code=308)

@app.route("/api/v1/acts/count",methods = ['GET'])
def total_acts():
	global ptr
	global count
	ptr+=1
	count+=1
	if(request.method=='GET'):
		return redirect(st_url+str(ports[ptr%(len(ports))])+"/api/v1/acts/count",code=308)

@app.route("/api/v1/_count",methods=['GET','DELETE'])
def count1():
	global count
	if(request.method=='GET'):
		return(jsonify([count]),200)
	elif(request.method=='DELETE'):
		count=0
		return('',200)

	return ('',405)



if __name__ == '__main__':
	app.run(host="0.0.0.0",port=80,debug=True)

