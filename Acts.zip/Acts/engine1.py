from flask import Flask, jsonify,abort
import  csv
import time
import hashlib
import re
from flask import make_response
import datetime
from flask import request
import requests
#import sys
#import subprocess
#from sets import Set
from flask import request
app=Flask(__name__)
@app.route('/api/v1/requests',methods=['GET'])
def forword_request():
    container1 = requests.get("http://34.203.190.166:8000/api/v1/_health")
    container2 = requests.get("http://34.203.190.166:8001/api/v1/_health")
    container3 = requests.get("http://34.203.190.166:8002/api/v1/_health")

    print(container1.status_code)
    print(container2.status_code)
    print(container3.status_code)
    if (container1.status_code==200) and (container2.status_code==200) and (con$
        return make_response(jsonify("{All containers are helthy}"),200)
    else:
        return make_response(jsonify("{There is some problem with container hea$
    print(c1)
    print(c2)
    print(c3)

def fault_tolerant():
    container1 = requests.get("http://34.203.190.166:8000/api/v1/_health")
    container2 = requests.get("http://34.203.190.166:8001/api/v1/_health")
    container3 = requests.get("http://34.203.190.166:8002/api/v1/_health")
    print(container1.status_code)
    print(container2.status_code)
    print(container3.status_code)
    if (container1.status_code==200) and (container2.status_code==200) and (con$
        return make_response(jsonify("{All containers are helthy}"),200)
    elif container1.status_code==500:
        return make_response(jsonify("{container1 have problem so troubleshoot $
    elif container2.status_code==500:
        return make_response(jsonify("{container2 have problem so troubleshoot $
    elif container3.status_code==500:
        return make_response(jsonify("{container3 have problem so troubleshoot $

    print(c1)
    print(c2)
    print(c3)


if __name__=='__main__':
    app.run(host='0.0.0.0',port=80)





